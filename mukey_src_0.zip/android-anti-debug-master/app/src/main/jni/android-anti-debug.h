/*
 * android-anti-debug.h
 *
 *  Created on: 2015年6月11日
 *      Author: liangwei
 */

#ifndef JNI_ANDROID_ANTI_DEBUG_H_
#define JNI_ANDROID_ANTI_DEBUG_H_


#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif


#endif /* JNI_ANDROID_ANTI_DEBUG_H_ */
