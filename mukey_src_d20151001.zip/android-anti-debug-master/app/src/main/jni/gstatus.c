
#include "gstatus.h"


t_gstatus   G_Status;

void INIT_GSTATUS()
{}

void SET_GSTATUS_XPOSED_PRESENT()
{ G_Status.xposed_present = 1;}


void SET_GSTATUS_LIBRARY_TAMPERED()
{ G_Status.lib_tampered = 1;  }


void SET_GSTATUS_BACKTRACE_STATUS()
{ G_Status.back_trace_status = 1; }