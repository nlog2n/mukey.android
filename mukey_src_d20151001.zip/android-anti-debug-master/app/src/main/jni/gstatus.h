#ifndef  __G_STATUS_H__
#define  __G_STATUS_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct _t_gstatus {
     //unsigned char username[128] = "demo";

// already included:
     int  xposed_present;   // JNI hook

     int  lib_tampered;     // anti patch
     unsigned int  lib1_signature; // must read from outside

     int  ptrace_status;    // ptrace check

     int   back_trace_status;   // gcc backtrace status

     int  java_backtrace_status;   // java backtrace

// TO be implemented:
     int   dex_tampered;
     int   dex_signature;  //  stored dex file CRC value

     //int  gdb_present;

} t_gstatus;



#ifdef __cplusplus
extern "C" {
#endif

void INIT_GSTATUS();
void SET_GSTATUS_XPOSED_PRESENT();
void SET_GSTATUS_LIBRARY_TAMPERED();
void SET_GSTATUS_BACKTRACE_STATUS();

#ifdef __cplusplus
}
#endif

#endif