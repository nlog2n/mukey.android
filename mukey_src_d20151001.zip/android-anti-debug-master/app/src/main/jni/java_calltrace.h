#ifndef  __JAVA_CALLTRACE_H__
#define  __JAVA_CALLTRACE_H__


#ifdef __cplusplus
extern "C" {
#endif

int validate_java_calltrace();

#ifdef __cplusplus
}
#endif



#endif