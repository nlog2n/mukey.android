#include <stdio.h>
#include <pthread.h>

#include <jni.h>


// The callback  should be in VM thread which loads the library.
// The JNI implementation maintains a JNIEnv per thread, and puts the pointer in thread-local storage.
// It is only initialized for native threads which are attached to the VM.
// You need to call AttachCurrentThread() (or more probably AttachCurrentThreadAsDaemon()) inside
// the callback to get a JNIEnv pointer valid for that thread.

// refer to: http://stackoverflow.com/questions/5991615/unable-to-get-jnienv-value-in-arbitrary-context

// https://developer.vuforia.com/library/articles/Solution/How-To-Communicate-Between-Java-and-C-using-the-JNI

// http://stackoverflow.com/questions/12900695/how-to-obtain-jni-interface-pointer-jnienv-for-asynchronous-calls

extern JavaVM *global_jvm;


static void OnJavaDetach(void* arg);

//this will be called when attached thread exit
void OnJavaDetach(void* arg)
{
    (*global_jvm)->DetachCurrentThread(global_jvm);

    //release thread key
    pthread_key_t *javaDetach = (pthread_key_t*)arg;

    pthread_setspecific(*javaDetach, NULL);
    pthread_key_delete(*javaDetach);

    free(javaDetach);
}


// attach VM context to current thread, which may not be the same thread as JNI_Onload
// Once attached the method can be called.
static JNIEnv * AttachCurrenThreadJEnv()
{
    JNIEnv *env;
    if ((*global_jvm)->AttachCurrentThread(global_jvm, &env, NULL)!= JNI_OK)
        return NULL;

    //create thread destructor
    pthread_key_t *javaDetach = malloc( sizeof(pthread_key_t));
    pthread_key_create(javaDetach, OnJavaDetach);
    //set thread key value so OnJavaDetach() will be called when attached thread exit
    pthread_setspecific(*javaDetach, javaDetach);

    return env;
}

JNIEnv * GetCurrenThreadJEnv()
{
    JNIEnv *env;
    // double check it's all ok
    jint re = (*global_jvm)->GetEnv(global_jvm, (void**)&env, JNI_VERSION_1_6);
    if(re == JNI_EDETACHED)
    {
        env = AttachCurrenThreadJEnv();
    }
    else if (re != JNI_OK)
        env = NULL;

    return env;
}


