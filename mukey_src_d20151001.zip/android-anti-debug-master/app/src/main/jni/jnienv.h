#ifndef  __JNIENV_H__
#define  __JNIENV_H__

#include <jni.h>


#ifdef __cplusplus
extern "C" {
#endif

JNIEnv * GetCurrenThreadJEnv();


#ifdef __cplusplus
}
#endif



#endif

