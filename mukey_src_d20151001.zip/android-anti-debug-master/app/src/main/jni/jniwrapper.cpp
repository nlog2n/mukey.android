#include <jni.h>


#include "macro.h"
#include "log.h"

#include "jni_hook.h"
#include "anti_patch.h"
#include "ptrace_check.h"
#include "bt_gccunwind.h"
#include "java_calltrace.h"
#include "dex_signature.h"

#include "jniwrapper.h"


JavaVM *global_jvm = NULL;   // cache the jvm
jobject  gCachedActivity = NULL;  // cache Java MainActivity class object


// refer to: http://stackoverflow.com/questions/18302837/android-jni-ndk-application-context
//  gCachedActivity now was used by dex_signature.c
JNIEXPORT void JNICALL Java_com_fanghui_antidebug_MainActivity_onCreateNative(JNIEnv *env, jobject thiz)
{
    gCachedActivity = env->NewGlobalRef(thiz);
}


JNIEXPORT jint Java_com_fanghui_antidebug_MainActivity_debuggerCheck(JNIEnv *, jobject obj)
{
   //  test JNI hook validation - anti xposed
   int status = validate_JNI_hook(Setting_Secure_cstr, getString_cstr, getSetringParam_cstr, 1);
   LOGE( "hook check getString status = %d", status );

   status = validate_JNI_hook(TelephonyManager_cstr, getDeviceId_cstr, getDeviceIdParam_cstr, 1);
   LOGE( "hook check getDeviceID status =%d", status );

   status = validate_JNI_hook(fanghui_java_class_name, fanghui_java_func_name, fanghui_java_func_params, 0);
   LOGE("hook check returnPwd status =%d", status );

   validate_JNI_hook2();


   // test android so library signature
   validate_signed_library2();

   // test ptrace deny protection. warning: this will deny adb debugger
   #if ENABLE_PTRACE_CHECK
    ptrace_deny();
	anti_debug1();
	//anti_debug2();
	#endif

   // test gcc backtrace validation
   status = validate_backtrace();
   validate_backtrace2();

   // test java call trace validation
   validate_java_calltrace();

   // test dex file signature
    compute_dexfile_signature();
    load_dexfile_signature();
    //validate_dexfile_signature();

   return status;
}




jint JNI_OnLoad(JavaVM* vm, void* reserved)
{

#if ENABLE_PTRACE_CHECK
    ptrace_deny();
	anti_debug1();
	//anti_debug2();
#endif

	JNIEnv* env;
	if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
	{
		return -1;
	}

	// cache this global jvm in order to get jenv later
	global_jvm = vm;

	return JNI_VERSION_1_6;
}
