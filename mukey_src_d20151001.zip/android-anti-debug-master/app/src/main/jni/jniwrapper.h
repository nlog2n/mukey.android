/*
 * jniwrapper.h
 *
 *  Created on: 2015-6-11
 *      Author: fanghui
 */

#ifndef __JNI_WRAPPER_H__
#define __JNI_WRAPPER_H__


#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jint Java_com_fanghui_antidebug_MainActivity_debuggerCheck(JNIEnv *, jobject obj);

JNIEXPORT void JNICALL Java_com_fanghui_antidebug_MainActivity_onCreateNative(JNIEnv *env, jobject thiz);



#ifdef __cplusplus
}
#endif


#endif /* __JNI_WRAPPER_H__ */
