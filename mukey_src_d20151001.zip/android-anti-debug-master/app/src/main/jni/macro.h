#ifndef  __MACRO_H__
#define  __MACRO_H__


#define  ENABLE_DEBUG_PRINT        1

#define  ENABLE_XPOSED_DETECTION   1
#define  ENABLE_GDB_DETECTION      0
#define  ENABLE_LIB_VALIDATION     1
#define  ENABLE_PTRACE_CHECK       0
#define  ENABLE_BACK_TRACE_CHECK   1
#define  ENABLE_DEX_FILE_SIGNATURE 1



#endif