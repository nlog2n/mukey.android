//#include <string>
//#include <chrono>
//#include <thread>

#include "ptrace_check.h"


// simply deny other debugger to attach since I did it myself in advance
void ptrace_deny()
{
  ptrace(PTRACE_TRACEME, 0, 0, 0);
}



//////////////////// debugger check method 1: ptrace
int ptrace_flag = 0;
void anti_debug1()
{
	if(ptrace(PTRACE_TRACEME, 0, 0, 0)==0)
	{
		ptrace_flag = 1;
	}
	else
	{
		if(ptrace_flag==0)
		{
			//try to kill the debugger
			ptrace(31, 0, 0, 0);
		}
	}
}



/////////////////////////   debugger check method 2
/*
void be_attached_check()
{
	try
	{
		const int bufsize = 1024;
		char filename[bufsize];
		char line[bufsize];
		int pid = getpid();
		sprintf(filename, "/proc/%d/status", pid);
		FILE* fd = fopen(filename, "r");
		if (fd != nullptr)
		{
			while (fgets(line, bufsize, fd))
			{
				if (strncmp(line, "TracerPid", 9) == 0)
				{
					int statue = atoi(&line[10]);
					LOGD("%s", line);
					if (statue != 0)
					{
						LOGD("be attached !! kill %d", pid);
						fclose(fd);
						int ret = kill(pid, SIGKILL);
					}
					break;
				}
			}
			fclose(fd);
		} else
		{
			LOGD("open %s fail...", filename);
		}
	} catch (...)
	{

	}

}
void thread_task(int n)
{
	while (true)
	{
		LOGD("start be_attached_check...");
		be_attached_check();
		std::this_thread::sleep_for(std::chrono::seconds(n));
	}
}
void anti_debug2()
{
	auto checkThread = std::thread(thread_task, 1);
	checkThread.detach();
}

*/
