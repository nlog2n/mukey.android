#ifndef  __PTRACE_CHECK_H__
#define  __PTRACE_CHECK_H__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fcntl.h>
#include <unistd.h>

#include <sys/ptrace.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>


#ifdef __cplusplus
extern "C" {
#endif


void ptrace_deny();
void anti_debug1();
//void anti_debug2();


#ifdef __cplusplus
}
#endif

#endif




