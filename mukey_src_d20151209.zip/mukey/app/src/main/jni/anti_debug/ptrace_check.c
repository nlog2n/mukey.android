#include <sys/ptrace.h>
#include <unistd.h>
#include <stdio.h>


#include "gstatus.h"

// simply deny other debugger to attach since I did it myself in advance
// too simple we do not use it.
/*
void ptrace_deny()
{
  ptrace(PTRACE_TRACEME, 0, 0, 0);
}
*/




//////////////////// debugger check method 1: ptrace
// note: this function may be called initially and later spammed into everywhere.
//int ptrace_flag = 0;  // initially there is no debugger attached.  // moved to inside gstatus
void ptrace_check()
{
	if(ptrace(PTRACE_TRACEME, 0, 0, 0)==0)
	{
	   // so far no gdb debugger attached, so I take the seat first.
		//ptrace_flag = 1;
		SET_GSTATUS_PTRACE_STATUS();
	}
	else   // found attachment, may be me or gdb..
	{
		//if(ptrace_flag !=  PTRACE_MY_SEAT_NUMBER)   // unfortunately i did not take that seat
		if ( !GET_GSTATUS_PTRACE_STATUS() )
		{
		    // so should be someone else
		    // set debugger status: make gstatus scrambled!
		    SCRAMBLE_GSTATUS();

			//try to kill the debugger
			//ptrace(31, 0, 0, 0);
		}
	}
}


