#ifndef  __PTRACE_CHECK_H__
#define  __PTRACE_CHECK_H__

#ifdef __cplusplus
extern "C" {
#endif


void ptrace_check();


#ifdef __cplusplus
}
#endif

#endif




