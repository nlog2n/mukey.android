#ifndef __THREAD_CHECK_H__
#define __THREAD_CHECK_H__


#ifdef __cplusplus
extern "C" {
#endif

void launch_thread_check();


#ifdef __cplusplus
}
#endif


#endif