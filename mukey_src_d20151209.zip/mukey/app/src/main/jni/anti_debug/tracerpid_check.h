#ifndef __TRACERPID_CHECK_H__
#define __TRACERPID_CHECK_H__


#ifdef __cplusplus
extern "C" {
#endif

int check_tracerpid();


#ifdef __cplusplus
}
#endif


#endif