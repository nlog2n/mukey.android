#ifndef  __BT_GCCUNWIND_H__
#define  __BT_GCCUNWIND_H__


#ifdef __cplusplus
extern "C" {
#endif

int validate_backtrace();
void validate_backtrace2();


#ifdef __cplusplus
}
#endif


#endif




