#ifndef __ANDROID_MAC_ADDR_BT_H__
#define __ANDROID_MAC_ADDR_BT_H__


#ifdef __cplusplus
extern "C" {
#endif


int get_bt_mac_address(unsigned char *pMacAddr);


#ifdef __cplusplus
}
#endif


#endif
