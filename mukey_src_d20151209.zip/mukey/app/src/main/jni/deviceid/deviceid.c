#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "log.h"
#include "deviceid.h"


void print_android_device_info(android_device_info* device)
{
    print_android_id(device->androidID);
    print_system_properties(&(device->sysInfo));
    print_android_cpuinfo(&(device->cpuInfo));
    LOGI("IMEI =%s", device->imei);
    LOGI("Wifi      "); print_mac_address(device->wifimacAddr);
    LOGI("Bluetooth "); print_mac_address(device->btmacAddr);
    LOGI("CID =%s", device->cid);
}


int read_android_device_info(android_device_info* device)
{
	int success;

	memset(device, 0, sizeof(android_device_info));

	// get android id
	success = get_jni_androidid(device->androidID);

	// get system properties
	success = get_system_properties(&(device->sysInfo));

	// get cpu info
	success = get_android_cpuinfo(&(device->cpuInfo));

	// get imei
	success = get_android_imei(device->imei);

	// get wifi mac address
	success = get_wifi_mac_address(device->wifimacAddr);

    // get bluetooth mac address
	success = get_bt_mac_address(device->btmacAddr);

	// get sd card number
	success = get_android_cid(device->cid);

	return success;
}

// detect emulator by checking system property info
// return:   1 - emulator, 0 - OK
int detect_emulator(android_device_info* device)
{
	int is_in_emulator = 0;
	int is_imei_inconsistent = 0;
	int is_wifi_mac_inconsistent = 0;
	int is_bt_mac_inconsistent = 0;

    // check system property info to see if serial exists
	if ( device->sysInfo.SerialNo.len == 0 )
	{
		// empty, must be in emulator
		LOGE("Warning: device serial number not found!");
		is_in_emulator = 1;
	}

    // check if two IMEIs are same
	char imei[128] = {0};
    int status =  get_jni_imei(imei); // 由于需要权限,该函数仅用来检测一致,不用来生成device ID
    if ( status == 0 )   // success
    {
       LOGI("IMEI (jni) = %s", imei);
       // compare only if IMEI from java is obtained (with permission allowed)
       if ( strlen(device->imei) > 0 )
       {
           if ( strcmp(device->imei, imei) != 0 )
           {
               LOGE("Warning: inconsistent IMEIs: %s, %s", imei, device->imei);
               is_imei_inconsistent = 1;
           }
       }
    }

    // check if two Wifi MAC addresses are same
    unsigned char wifiMac2[6] = {0};
    status = check_wifi_mac_address(wifiMac2);
    if (status)
    {
       if ( is_valid_mac_addr(wifiMac2)  &&  is_valid_mac_addr(device->wifimacAddr) )
       {
       if ( !is_equal_mac_addrs(wifiMac2, device->wifimacAddr) )
       {
          LOGE("Warning: inconsistent Wifi MACs:");
          print_mac_address(wifiMac2);
          print_mac_address(device->wifimacAddr);
          is_wifi_mac_inconsistent = 1;
       }

       }
    }
    // further check wifi mac against jni result
    unsigned char wifiMac3[6] = {0};
    status = get_jni_wifimac(wifiMac3);
    if (status == 0)
    {
       if ( is_valid_mac_addr(device->wifimacAddr)  && is_valid_mac_addr(wifiMac3) )
       {
           if ( !is_equal_mac_addrs(device->wifimacAddr, wifiMac3) )
           {
                         LOGE("Warning: inconsistent Wifi MACs:");
                         print_mac_address(wifiMac3);
                         print_mac_address(device->wifimacAddr);
                         is_wifi_mac_inconsistent = 1;
           }
       }
    }

    // check if two bt MAC addresses are same
    unsigned char btMac2[6] = {0};
    status = get_jni_btmac(btMac2);
    if ( status == 0 )
    {
       LOGI("Bluetooth MAC(jni):"); print_mac_address(btMac2);
       if ( is_valid_mac_addr(device->btmacAddr)  && is_valid_mac_addr(btMac2) )
       {
           if ( !is_equal_mac_addrs(device->btmacAddr, btMac2) )
           {
                         LOGE("Warning: inconsistent Wifi MACs:");
                         print_mac_address(btMac2);
                         print_mac_address(device->btmacAddr);
                         is_bt_mac_inconsistent = 1;
           }
       }
    }

	return (is_in_emulator || is_imei_inconsistent || is_wifi_mac_inconsistent || is_bt_mac_inconsistent);
}


// compute hash for whole device information
unsigned int generate_device_id(android_device_info* device)
{
	int i;
	unsigned int hash = 0;
	unsigned char* ptr = (unsigned char*)device;
	for(i=0; i < sizeof(android_device_info); i++)
	{
		hash +=  *(ptr+i);
	}
	LOGI("\n====>android device hash: %d\n", hash);
	return hash;
}



#ifdef  TEST_BACKTRACE

int main()
{
	android_device_info device;
	read_android_device_info(&device);
	print_android_device_info(&device);
	generate_device_id(&device);
	detect_emulator(&device);
	return 0;
}

#endif