
#include "gstatus.h"


t_gstatus   G_Status;

void INIT_GSTATUS()
{}

void SET_GSTATUS_XPOSED_PRESENT()
{ G_Status.xposed_present = 1;}


void SET_GSTATUS_LIBRARY_TAMPERED()
{ G_Status.lib_tampered = 1;  }


void SET_GSTATUS_BACKTRACE_STATUS()
{ G_Status.back_trace_status = 1; }


void SET_GSTATUS_PTRACE_STATUS()
{ G_Status.ptrace_status = PTRACE_MY_SEAT_NUMBER; }


int  GET_GSTATUS_PTRACE_STATUS()
{ return (G_Status.ptrace_status == PTRACE_MY_SEAT_NUMBER ); }


void SCRAMBLE_GSTATUS()
{
   // TODO: change any bytes in gstatus
}

// return:  key length (and set buffer)
int  getKey(const unsigned char *buffer)
{
    return 0;
}