#ifndef  __G_STATUS_H__
#define  __G_STATUS_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define  PTRACE_MY_SEAT_NUMBER     0x35919513   // magic number

typedef struct _t_gstatus {
     //unsigned char username[128] = "demo";

// already included:
     int  xposed_present;   // JNI hook

     int  lib_tampered;     // anti patch
     unsigned int  lib1_signature; // must read from outside

     int  ptrace_status;    // ptrace check flag: should be set to my seat number
     // to obfuscate, initially it should be set to random value except my seat number
     // and later ptrace_check will correct this value.

     int   back_trace_status;   // gcc backtrace status

     int  java_backtrace_status;   // java backtrace

// TO be implemented:
     int   dex_tampered;
     int   dex_signature;  //  stored dex file CRC value

     //int  gdb_present;

} t_gstatus;



#ifdef __cplusplus
extern "C" {
#endif

void INIT_GSTATUS();
void SET_GSTATUS_XPOSED_PRESENT();
void SET_GSTATUS_LIBRARY_TAMPERED();
void SET_GSTATUS_BACKTRACE_STATUS();

void SET_GSTATUS_PTRACE_STATUS();  // set correct value
int  GET_GSTATUS_PTRACE_STATUS();

void SCRAMBLE_GSTATUS();   // this will lock mukey service


int  getKey(const unsigned char *buffer);  // mukey service

#ifdef __cplusplus
}
#endif

#endif