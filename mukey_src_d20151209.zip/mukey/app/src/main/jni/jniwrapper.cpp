#include "macro.h"
#include "gstatus.h"
#include "log.h"

// anti debug
#include "anti_debug/ptrace_check.h"
#include "anti_debug/tracerpid_check.h"
#include "anti_debug/thread_check.h"

// anti hook
#include "backtrace/bt_gccunwind.h"
#include "ld_preload/ld_preload.h"

// anti tampering
#include "anti_patch/anti_patch.h"

// JNI related
#include "jnienv.h"
#include "jni_hook/jni_hook.h"
#include "java_calltrace/jni_calltrace.h"
#include "dex_signature/jni_dex_sign.h"

// device id
#include "deviceid/deviceid.h"

#include "jniwrapper.h"


JavaVM *global_jvm = NULL;   // cache jvm
JNIEnv *global_jvm_env = NULL;    // cache jvm env
jobject global_Activity = NULL;  // cache Java MainActivity class object

extern int initial_tracer_pid;

extern int keepAlive;  // for gracefully terminating the thread


// refer to: http://stackoverflow.com/questions/18302837/android-jni-ndk-application-context
//  global_Activity now was used by dex_signature.c
JNIEXPORT void JNICALL Java_com_nlog2n_mukey_MainActivity_onCreateNative(JNIEnv *env, jobject thiz)
{
    global_Activity = env->NewGlobalRef(thiz);
}


JNIEXPORT void JNICALL Java_com_nlog2n_mukey_MainActivity_onDestroy(JNIEnv *, jobject obj)
{
    keepAlive = 0;
}

JNIEXPORT jint Java_com_nlog2n_mukey_MainActivity_GenOTP(JNIEnv *, jobject obj)
{
   int status = 0;

   //  test JNI hook validation - anti xposed
   #if ENABLE_JNI_HOOK_DETECTION
   // java system method: getString
   status = validate_JNI_hook(Setting_Secure_cstr, getString_cstr, getSetringParam_cstr, 1);
   LOGE( "hook check getString status = %d", status );
   // java system method: getDeviceId
   status = validate_JNI_hook(TelephonyManager_cstr, getDeviceId_cstr, getDeviceIdParam_cstr, 1);
   LOGE( "hook check getDeviceID status =%d", status );
   // user defined java method:
   status = validate_JNI_hook(fanghui_java_class_name, fanghui_java_func_name, fanghui_java_func_params, 0);
   LOGE("hook check returnPwd status =%d", status );
   // a general sample
   validate_JNI_hook2();
   #endif


   // test android so library signature
   #if  ENABLE_LIBRARY_SIGNATURE_CHECK
   validate_signed_library2();
   #endif

   // test ptrace deny protection. warning: this will deny adb debugger
   #if ENABLE_PTRACE_DETECTION
    ptrace_check();
	#endif

   // test gcc backtrace validation
   #if ENABLE_GCC_BACKTRACE_CHECK
   status = validate_backtrace();
   validate_backtrace2();
   #endif

   // test java call trace validation
   #if ENABLE_JAVA_BACKTRACE_CHECK
   validate_java_calltrace();
   #endif

   // test dex file signature
   #if ENABLE_DEX_FILE_SIGNATURE_CHECK
    compute_dexfile_signature();
    load_dexfile_signature();
    //validate_dexfile_signature();
   #endif

   // test tracerpid to see any debugger attached
   #if ENABLE_TRACER_PID_CHECK
   status = check_tracerpid();
   LOGE("tracerpid status =%d", status );
   	//anti_debug2();
   #endif

   // test if any LD_PRELOAD library defined
   #if ENABLE_LD_PRELOAD_CHECK
   	t_libc_function_pointers g_func_pointers;
   	status = init_libc_function_pointers(&g_func_pointers);
   	LOGE("ld preload status =%d", status);
   #endif

   // test android device information get
   #if ENABLE_SYSTEM_PROPERTY_GET
   	android_device_info device;
   	read_android_device_info(&device);
   	print_android_device_info(&device);
   	generate_device_id(&device);
   	detect_emulator(&device);
   #endif

   return status;
}




jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    initial_tracer_pid  = getppid();

#if ENABLE_PTRACE_CHECK
    ptrace_check();  // put here to preempt other debuggers
#endif

#if ENABLE_THREAD_CHECK
    launch_thread_check();
#endif

	JNIEnv* env;
	if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
	{
		return -1;
	}

	// cache this global jvm in order to get jenv later
	global_jvm = vm;
	global_jvm_env = GetCurrenThreadJEnv();

	return JNI_VERSION_1_6;
}
