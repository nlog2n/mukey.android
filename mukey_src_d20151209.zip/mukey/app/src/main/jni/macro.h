#ifndef  __MACRO_H__
#define  __MACRO_H__


#define  ENABLE_DEBUG_PRINT        1



// threat intelligence features

#define  ENABLE_JNI_HOOK_DETECTION          1

#define  ENABLE_GDB_DETECTION               0

#define  ENABLE_LIBRARY_SIGNATURE_CHECK     1

#define  ENABLE_PTRACE_DETECTION            0

#define  ENABLE_GCC_BACKTRACE_CHECK         1

#define  ENABLE_JAVA_BACKTRACE_CHECK        1

#define  ENABLE_DEX_FILE_SIGNATURE_CHECK    1

#define  ENABLE_TRACER_PID_CHECK            1

#define  ENABLE_THREAD_CHECK                0

#define  ENABLE_LD_PRELOAD_CHECK            1

#define  ENABLE_SYSTEM_PROPERTY_GET         1



#endif